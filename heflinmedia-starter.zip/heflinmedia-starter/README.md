# Heflin Media Group — Website Starter

A responsive static website, designed for GitHub Pages. This is a **draft concept**, not a finished public site.

## Pages
- `index.html` — homepage
- `book-development.html` — strategy, coaching, manuscript development, editing
- `ghostwriting.html` — direct-with-Liz vs team-led engagements
- `publishing.html` — publishing pathways and Wynncrest relationship
- `about.html` — company and talent model
- `contact.html` — inquiry page (form not yet connected)
- `assets/css/style.css` — global styling
- `assets/js/site.js` — mobile navigation and footer year

## How to preview
Open `index.html` in a browser, or use `python -m http.server 8000` in the folder and browse to localhost:8000.

## GitHub Pages
1. On GitHub, create a new public repository named `heflinmedia` (do not initialize it with a README).
2. Upload **all files and folders in this package** at repository root; commit to `main`.
3. In repository Settings > Pages, select **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Preview at `https://YOUR-USERNAME.github.io/heflinmedia/`.
5. Do **not** configure the `heflinmedia.com` custom domain or change DNS until the site is approved for launch.

## Before launch
- Replace placeholder / conceptual copy with confirmed client-proof and credentials.
- Replace text wordmark with approved logo and brand assets.
- Connect inquiry form to Airtable/Formspree or the agreed endpoint, including privacy notice, consent, validation, abuse protection, and success handling. **The sample inquiry form is deliberately not live.**
- Add approved case studies/testimonials only after checking publication and confidentiality rights.
- Decide whether starting investment ranges should appear on service pages.
- Add privacy and legal pages, cookie disclosure if applicable, analytics and SEO metadata as appropriate.
- Check accessibility, browser behavior and mobile layouts before DNS cutover.
