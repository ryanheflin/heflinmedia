const menu = document.querySelector('.menu-button');
const links = document.querySelector('.navlinks');
if (menu && links) {
  menu.addEventListener('click', () => {
    const open = links.classList.toggle('is-open');
    menu.setAttribute('aria-expanded', String(open));
  });
  links.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    links.classList.remove('is-open');
    menu.setAttribute('aria-expanded', 'false');
  }));
}
const year = document.querySelector('[data-year]');
if (year) year.textContent = new Date().getFullYear();
